import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def calculate_match_scores(resume_text: str, csv_path: str = "data/job_roles.csv"):
    df = pd.read_csv(csv_path)
    job_roles = df["Job Role"].tolist()
    job_skills = df["Required Skills"].tolist()
    
    # Combine resume text with job requirements for vectorization
    documents = [resume_text] + job_skills
    
    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf_matrix = vectorizer.fit_transform(documents)
    
    # Resume vector is the first row, job vectors are subsequent rows
    resume_vector = tfidf_matrix[0:1]
    job_vectors = tfidf_matrix[1:]
    
    similarities = cosine_similarity(resume_vector, job_vectors).flatten()
    
    df["Match Score"] = (similarities * 100).round(2)
    df = df.sort_values(by="Match Score", ascending=False).reset_index(drop=True)
    
    return df