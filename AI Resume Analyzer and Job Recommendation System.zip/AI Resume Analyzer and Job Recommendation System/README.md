# AI Resume Analyzer & Career Roadmap Generator

An interactive Streamlit web application that analyzes uploaded resumes, generates personalized career roadmaps, and recommends matched job roles.

---

## 🚀 Features

- **Resume Analysis:** Upload your resume in supported formats (PDF, DOCX).
- **Personalized Roadmap:** Receive a detailed, step-by-step career development roadmap based on your current profile.
- **Job Role Matching:** Discover key job roles that fit your skills, along with skill gaps to bridge.

---

## ⚙️ Installation & Running the Application

Follow the steps below to run the app using **Visual Studio Code**:

### Step 1: Open VS Code Terminal
Open your project folder in VS Code, then open the integrated terminal (`Ctrl + \` ` or `Cmd + \` `).

### Step 2: Install Required Dependencies
Type and run the following command to install all required packages:

```bash
pip install -r requirements.txt
```

### Step 3: Launch the Streamlit App
After the installation completed, start the web interface by running:

```bash
streamlit run app.py
```

---

## 🎯 How to Use

1. Once the **Streamlit interface** opens automatically in your browser:
2. **Upload your resume** using the file uploader tool.
3. View your generated **Career Roadmap** and **Matched Job Roles**.