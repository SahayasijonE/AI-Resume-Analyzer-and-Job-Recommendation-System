import pandas as pd
import os

def load_skills():
    # Default comprehensive skill set matching project guidelines
    return [
        "python", "sql", "excel", "pandas", "power bi", "ml", "scikit-learn", 
        "fastapi", "docker", "numpy", "deep learning", "llm", "rag", "apis", 
        "langchain", "nlp", "transformers", "hugging face", "pytorch", "spacy", 
        "opencv", "cnn", "yolo", "image processing", "git", "aws", "statistics"
    ]

def extract_skills(text: str) -> list:
    skills_list = load_skills()
    found_skills = []
    for skill in skills_list:
        # Use word boundary matching to avoid partial word mismatches
        if skill in text:
            found_skills.append(skill.title())
    return list(set(found_skills))