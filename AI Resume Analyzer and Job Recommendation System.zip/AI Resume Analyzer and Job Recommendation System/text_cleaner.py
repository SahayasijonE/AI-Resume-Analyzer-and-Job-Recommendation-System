import re

def clean_text(text: str) -> str:
    """
    Cleans unstructured resume text: converts to lowercase,
    removes extra whitespaces and unwanted symbols while preserving C++, C#, .NET.
    """
    if not text:
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Preserve important technical symbols like C++, C#, .net temporarily or handle regex safely
    # For general cleaning, remove special characters except basic punctuation and plus/hash/dots
    text = re.sub(r'[^\w\s\+\#\.]', ' ', text)
    
    # Remove extra spaces and newlines
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text