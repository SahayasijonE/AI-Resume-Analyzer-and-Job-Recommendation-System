import streamlit as st
import pandas as pd
from resume_parser import parse_resume
from text_cleaner import clean_text
from skill_extractor import extract_skills
from job_matcher import calculate_match_scores
from roadmap_generator import generate_groq_roadmap

st.set_page_config(page_title="AI Resume Analyzer & Job Recommendation", layout="wide")

st.title("📄 AI Resume Analyzer & Job Recommendation System")
st.markdown("Upload your resume to evaluate skill matches, find missing competencies, and receive a customized Groq-powered learning roadmap.")

uploaded_file = st.file_uploader("Upload Resume (PDF or DOCX)", type=["pdf", "docx"])

if uploaded_file is not None:
    with st.spinner("Extracting and analyzing resume..."):
        raw_text = parse_resume(uploaded_file)
        cleaned_text = clean_text(raw_text)
        found_skills = extract_skills(cleaned_text)
        
        df_matches = calculate_match_scores(cleaned_text)
        
    st.success("Resume processed successfully!")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🔍 Extracted Skills")
        if found_skills:
            st.write(", ".join(found_skills))
        else:
            st.warning("No standard technical skills detected. Try adding more details to your resume.")
            
    with col2:
        st.subheader("📊 Top Job Recommendations")
        st.dataframe(df_matches[["Job Role", "Match Score"]])
        
    st.markdown("---")
    st.subheader("🎯 Skill-Gap Analysis & Learning Roadmap")
    
    selected_role = st.selectbox("Select Target Role for Detailed Gap Analysis", df_matches["Job Role"].tolist())
    
    if selected_role:
        required_skills_str = df_matches[df_matches["Job Role"] == selected_role]["Required Skills"].values[0]
        required_skills = [s.strip() for s in required_skills_str.split(",")]
        
        candidate_skills_lower = [s.lower() for s in found_skills]
        missing_skills = [s for s in required_skills if s not in candidate_skills_lower]
        
        col_m1, col_m2 = st.columns(2)
        with col_m1:
            st.markdown(f"**Required Skills for {selected_role}:**")
            st.write(", ".join(required_skills))
        with col_m2:
            st.markdown("**Missing Skills:**")
            if missing_skills:
                st.error(", ".join(missing_skills))
            else:
                st.success("You have all the core required skills for this role!")
                
        if missing_skills:
            if st.button("Generate Groq AI Learning Roadmap"):
                with st.spinner("Generating roadmap using Groq..."):
                    roadmap = generate_groq_roadmap(missing_skills, selected_role)
                    st.markdown("### 🗺️ Custom Learning Roadmap")
                    st.write(roadmap)