import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

def generate_groq_roadmap(missing_skills: list, target_role: str) -> str:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        return "Groq API key not found. Please check your .env file."
    
    client = Groq(api_key=api_key)
    
    prompt = f"""
    The candidate is applying for a {target_role} position.
    Based on a skill-gap analysis, they are missing the following skills: {', '.join(missing_skills)}.
    Generate a concise, 4-week structured learning roadmap to help them acquire these missing skills.
    Keep it actionable and formatted with weeks.
    """
    
    try:
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": "You are an expert technical career coach."},
                {"role": "user", "content": prompt}
            ],
            model="llama-3.1-8b-instant",  # Updated active model name
        )
        return chat_completion.choices[0].message.content
    except Exception as e:
        return f"Error generating roadmap via Groq: {str(e)}"